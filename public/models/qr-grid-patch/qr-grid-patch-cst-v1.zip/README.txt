QR-grid patch antenna / CST / FIT / v1
Software used for the archived project: CST 2026.1
Engineering archive: 2026-08-04

AI-assisted reproduction: Lavax / RF Agent Lab.
Original antenna design and topology-optimization method: X. Ma, Y. Zong, P. Zhang, J. Chen, Z. Ren, Z. Liu, and C. Li
Design of Multiband Patch Antennas Using Adaptive Topology Optimization Method
IEEE Transactions on Antennas and Propagation, 2026, 74(1): 38–50.
DOI: https://doi.org/10.1109/TAP.2025.3623329

This package contains the unchanged core native files listed below, not the full
result-preserving archive. External result/cache folders are NOT included.
Opening, recalculating and inspecting saved results require the corresponding
licensed engineering software. Compatibility with older releases is not verified.
This website update did not reopen or solve the model. The paper and course report
are not distributed. The reproduction uses the final geometry, not a rerun of
the original topology optimization. No rights to the original publication are granted.

Files (SHA-256):
QR_Patch_CST_TD_WaveguidePort_20260728_v1.cst  384a10d6ec895aee3a1f631d9634a8ea6887d9f64ff6f63e5b29500d4d3e8585