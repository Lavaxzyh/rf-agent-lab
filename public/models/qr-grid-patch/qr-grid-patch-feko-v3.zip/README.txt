QR-grid patch antenna / FEKO / MoM / v3
Software used for the archived project: FEKO 2026.0
Engineering archive: 2026-08-04

AI-assisted reproduction: Lavax / RF Agent Lab.
Original antenna design and topology-optimization method: X. Ma, Y. Zong, P. Zhang, J. Chen, Z. Ren, Z. Liu, and C. Li
Design of Multiband Patch Antennas Using Adaptive Topology Optimization Method
IEEE Transactions on Antennas and Propagation, 2026, 74(1): 38–50.
DOI: https://doi.org/10.1109/TAP.2025.3623329

This package contains the unchanged core native files listed below, not the full
result-preserving archive. External result/cache folders are NOT included.
Opening, recalculating and inspecting saved results require the corresponding
licensed engineering software. Compatibility with older releases is not verified.
This website update did not reopen or solve the model. The paper and course report
are not distributed. The reproduction uses the final geometry, not a rerun of
the original topology optimization. No rights to the original publication are granted.

Files (SHA-256):
QR_Patch_MoM_EdgePort_20260728_v3.cfx  bb19c72725949b96a0d4284f61fc2ff3caa3d6623490502f494bf75fbaaa0a80
QR_Patch_MoM_EdgePort_20260728_v3.fek  4fd1ed6ad36050929e1435c096b8c15cc85f32e2ab2dc86319041d382c9111bb